#ifdef Begin_AI
inline pair<int,int>getdiff(Gird x,Gird y){
	for(int i=1;i<=15;++i){
		for(int j=1;j<=15;++j){
			if(x.G[i][j]!=y.G[i][j])return mp(i,j);
		}
	}
	return {-1,-1};
}
inline void Player_to_computer(){
	cout<<"Input 1 if you want first,otherwise input 2.\n";
	int T;cin>>T;
	int Now_Turn=T;
	Load();
	system("cls");
	Gird gird;
	gird.init();
	pair<int,int>p;
	for(;!gird.Win();){
		if(gird.Draw()){
			cout<<"Draw!!\n";
			return;
		}
		int x,y;
		gird.Print(Now_Turn);
		cout<<"last move: "<<p.first<<' '<<p.second<<'\n';
		if(Now_Turn==1){
			for(;;){
				cout<<"Input where your chess put: \n";
				cout<<"Line: ";cin>>x;cout<<'\n';
				cout<<"Column: ";cin>>y;cout<<'\n';
				if(x<=15 and y<=15 and x>=1 and y>=1 and !gird.G[x][y])break;
				cout<<"Wrong Input!\nPlease enter it again.\n";
			}
			gird.G[x][y]=Now_Turn;			
		}else{
			Gird T=gird;
			gird=AI_esay(gird);
			p=getdiff(T,gird);
		}
		if(gird.Win()!=0){
			gird.Print(Now_Turn);
			char T=gird.Get(Now_Turn);
			if(T=='X')cout<<"Player";else cout<<"Computer";
			cout<<" wins!\n";
			return;
		}
		Now_Turn=Next_Turn(Now_Turn);
	}
}
#endif
